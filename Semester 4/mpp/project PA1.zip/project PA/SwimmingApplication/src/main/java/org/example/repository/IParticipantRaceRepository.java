package org.example.repository;

import org.example.model.ParticipantRace;

public interface IParticipantRaceRepository extends IRepository<Integer,ParticipantRace>{
}
