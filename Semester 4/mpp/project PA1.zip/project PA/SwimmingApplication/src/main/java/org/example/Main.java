package org.example;

import org.example.model.Participant;
import org.example.repository.IParticipantRepository;
import org.example.repository.ParticipantRepository;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Main {
    public static void main(String[] args) {

        Properties props = new Properties();

        try {
            props.load(new FileReader("D:\\sem4\\project PA\\SwimmingApplication\\src\\main\\resources\\db.properties"));
        } catch (IOException e) {
            System.out.println("Cannot find db.properties: " + e);
            return;
        }

        IParticipantRepository participantRepository = new ParticipantRepository(props);
        System.out.println("Test ParticipantRepository: ");
        Participant participant1 = new Participant("Adela",26);
        participantRepository.save(participant1);

        for(Participant p : participantRepository.findAll()){
            System.out.println(p);
        }
    }
}