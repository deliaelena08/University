package org.example.repository;

import org.example.model.Race;

public interface IRaceRepository extends IRepository< Integer,Race>{
}
